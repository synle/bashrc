import os

import advanced_options
import controller_utils
import decky_plugin
import device
import file_timeout
import mapping_profiles
import migrations
import plugin_settings
import plugin_update
from controller_modes import get_controller_mode_options


class Plugin:
    # Asyncio-compatible long-running code, executed in a task when the plugin is loaded
    async def _main(self):
        decky_plugin.logger.info("Hello World!")
        controller_utils.clear_state_file()
        try:
            mapping_profiles.capture_base_profile()
        except Exception as e:
            decky_plugin.logger.error(f"Failed to capture base profile: {e}")

    async def get_settings(self):
        results = plugin_settings.get_settings()

        try:
            results["controllerModeOptions"] = get_controller_mode_options()
            results["pluginVersionNum"] = f"{decky_plugin.DECKY_PLUGIN_VERSION}"
            results["advancedOptions"] = advanced_options.get_options()
            results["mappingProfiles"] = mapping_profiles.get_all_profiles()
            results["deviceName"] = device.get_device_name()
            results["currentProfileInfo"] = mapping_profiles.get_base_profile_info()
        except Exception as e:
            decky_plugin.logger.error(e)

        return results

    async def save_per_game_profiles_enabled(self, enabled: bool):
        return plugin_settings.set_setting("perGameProfilesEnabled", enabled)

    async def set_setting(self, name: str, value):
        try:
            if name == "advanced":
                advanced_options.handle_advanced_option_change(value)

            return plugin_settings.set_setting(name, value)
        except Exception as e:
            decky_plugin.logger.error(f"error failed to set_setting {name}={value} {e}")

    async def save_controller_settings(self, payload):
        currentGameId = payload.get("currentGameId")
        controllerProfiles = payload.get("controllerProfiles")
        result = plugin_settings.set_all_controller_profiles(controllerProfiles)

        if currentGameId:
            controller_utils.sync_controller_settings(currentGameId)
        return result

    # ----- Mapping Profile CRUD -----

    async def get_profile_detail(self, profile_id: str):
        try:
            return mapping_profiles.get_profile_detail(profile_id)
        except Exception as e:
            decky_plugin.logger.error(f"get_profile_detail error: {e}")
            return None

    async def create_custom_profile(self, data: dict):
        try:
            return mapping_profiles.create_custom_profile(data)
        except Exception as e:
            decky_plugin.logger.error(f"create_custom_profile error: {e}")
            return {"error": str(e)}

    async def update_custom_profile(self, profile_id: str, data: dict):
        try:
            return mapping_profiles.update_custom_profile(profile_id, data)
        except Exception as e:
            decky_plugin.logger.error(f"update_custom_profile error: {e}")
            return {"error": str(e)}

    async def delete_custom_profile(self, profile_id: str):
        try:
            mapping_profiles.delete_custom_profile(profile_id)
            return {"success": True}
        except Exception as e:
            decky_plugin.logger.error(f"delete_custom_profile error: {e}")
            return {"error": str(e)}

    async def duplicate_profile(self, source_id: str, new_name: str):
        try:
            return mapping_profiles.duplicate_profile(source_id, new_name)
        except Exception as e:
            decky_plugin.logger.error(f"duplicate_profile error: {e}")
            return {"error": str(e)}

    # ----- End Mapping Profile CRUD -----

    async def on_suspend(self, currentGameId):
        decky_plugin.logger.info(f"on_suspend called with {currentGameId}")

    async def on_resume(self, currentGameId):
        decky_plugin.logger.info(f"on_resume called with {currentGameId}")

    # sync state in settings.json to actual controller hardware
    async def sync_controller_settings(self, currentGameId):
        return controller_utils.sync_controller_settings(currentGameId)

    async def ota_update(self):
        # trigger ota update
        try:
            with file_timeout.time_limit(15):
                return plugin_update.ota_update()
        except Exception as e:
            decky_plugin.logger.error(e)

    async def get_latest_version_num(self):
        return plugin_update.get_latest_version()

    # Function called first during the unload process, utilize this to handle your plugin being removed
    async def _unload(self):
        decky_plugin.logger.info("Goodbye World!")
        pass

    # Migrations that should be performed before entering `_main()`.
    async def _migration(self):
        decky_plugin.logger.info("Migrations")
        try:
            migrations.migrate_deck_target()
        except Exception as e:
            decky_plugin.logger.error("{__name__} error during migrations {e}")

    async def log_info(self, info):
        decky_plugin.logger.info(info)
